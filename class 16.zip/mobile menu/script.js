$(document).ready(function(){
	$('.responsive_bar').click(function(){
		$('.menu ul').slideToggle(200);
	});
});