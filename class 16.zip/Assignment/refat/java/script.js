function touch(){
	var name = document.getElementById('fname');
	var lname= document.getElementById('lname');
	
	if(name.value==''){
		document.getElementById('fname_ero').innerHTML = 'Enter your First Name';
		name.focus();
		return false;
	}
	else{
		document.getElementById('fname_ero').innerHTML = '';
	}
	
	if(lname.value == ''){
		document.getElementById('lname_ero').innerHTML = 'Enter your First Name';
		lname.focus();
		return false;
	}
}