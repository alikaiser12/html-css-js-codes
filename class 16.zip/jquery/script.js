$(document).ready(function(){
	$('.hide').click(function(){
		$('.img3').slideUp(200);
	});
	$('.show').click(function(){
		$('.img3').slideDown(200);
	});
});