function touch(){
	var name = document.getElementById("name");
	var email = document.getElementById("email");
	var web = document.getElementById("web");
	var msg = document.getElementById("msg");
	
	if(name.value == ""){
		document.getElementById("name_error").innerHTML = "Please, Enter Your Name";
		name.focus();
		return false;
	}else{
		document.getElementById("name_error").innerHTML = "";
	}
	if(email.value==""){
		document.getElementById("email_error").innerHTML = "Please, Enter Your Email Address";
		email.focus();
		return false;
	}
	else{
		document.getElementById("email_error").innerHTML = "";
	}
	if(web.value==""){
		document.getElementById("web_error").innerHTML = "Please, Enter Your Website Address";
		web.focus();
		return false;
	}
	else{
		document.getElementById("web_error").innerHTML = "";
	}
	if(msg.value==""){
		document.getElementById("msg_error").innerHTML = "Please, Enter Your Message Here";
		msg.focus();
		return false;
	}
	else{
		document.getElementById("msg_error").innerHTML = "";
	}
}