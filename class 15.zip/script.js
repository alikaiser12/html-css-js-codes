function touch(){
	var name = document.getElementById('fname');
	var lname = document.getElementById('lname');
	var subject = document.getElementById('subject');
	var email = document.getElementById('email');
	var pw = document.getElementById('pw');
	var rpw = document.getElementById('rpw');
	
	if(name.value == ''){	
		document.getElementById('fname_error').innerHTML = "Please Enter First Name";
		name.focus();
		return false;
	}else{
		document.getElementById('fname_error').innerHTML= "";
	}
	
	if(lname.value == ''){
		document.getElementById('lname_error').innerHTML = "Please Enter Last Name";
		lname.focus();
		return false;
	}else{
		document.getElementById('lname_error').innerHTML = "";
	}
	
	if(subject.value == ''){
		document.getElementById('subject_error').innerHTML = "Please Enter Your Subject";
		subject.focus();
		return false;
	}else{
		document.getElementById('subject_error').innerHTML = "";
	}
	
	if(email.value == ''){
		document.getElementById('email_error').innerHTML = "Please Enter Your Email";
		email.focus();
		return false;
	}else{
		document.getElementById('email_error').innerHTML = "";
	}
	
	if(pw.value == ''){
		document.getElementById('pw_error').innerHTML = "Please Enter Your Password";
		pw.focus();
		return false;
	}else if(pw.value.length <= 5){
		document.getElementById('pw_error').innerHTML = "Add minimum 6 charactar";
		pw.focus();
		return false;
	}else{
		document.getElementById('pw_error').innerHTML = "";
	}
	
	if(pw.value != rpw.value){
		document.getElementById('rpw_error').innerHTML = "Password does not matched";
		rpw.focus();
		return false;
	}else{
		document.getElementById('rpw_error').innerHTML = "";
	}
	
	
	
}