$(document).ready(function(){
	$('#menubar').click(function(){
		$('.menu').children('ul').slideToggle();
	});
});