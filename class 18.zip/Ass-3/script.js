$(document).ready(function(){
	$('.responsive_bar').click(function(){
		$('.menu ul').slideDown(200);
	});
});