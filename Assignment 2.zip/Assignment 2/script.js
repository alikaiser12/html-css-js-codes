$(document).ready(function(){
	$('.responsive').click(function(){
		$('.menu ul').slideToggle(200);
	});
});