$(document).ready(function(){
	$('.responsive_bar').click(function(){
		$('.menu ul').slideToggle(200);
	});
});
$(document).ready(function(){
	$('.menu ul li').click(function(){
		$('.menu ul ul').slideToggle(200);
	});
});
$(document).ready(function(){
	$('.menu ul ul li').click(function(){
		$('.menu ul ul ul').slideToggle(200);
	});
});