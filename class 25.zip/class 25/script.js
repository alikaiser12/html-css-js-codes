$(document).ready(function(){
	$('.responsive_bar').click(function(){
		$('.menu').children('ul').slideToggle(200);
	});
});