<!DOCTYPE html>
<html>
	<head>
		<title>Form Design</title>
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

	</head>
	<body>
		
		<div class="container mt-5">
			<form>
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="fname">First Name </label>
							<input type="text" id="fname" class="form-control">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="lname">Last Name </label>
							<input type="text" id="lname" class="form-control">
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="subject">Subject </label>
							<input type="text" id="subject" class="form-control">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="email"> Email </label>
							<input type="email" id="email" class="form-control">
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="form-group">
							<label for="texts"> Message </label>
							<textarea class="form-control" id="texts"></textarea>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="form-group">
							<h5>Gendar</h5>
							<input type="radio" id="male" name="gender" value="male">
							  <label for="male">Male</label>
							  <input type="radio" id="female" name="gender" value="female">
							  <label for="female">Female</label>
							  <input type="radio" id="other" name="gender" value="other">
							  <label for="other">Other</label>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<div class="form-group">
							<h5>Jobs</h5>
							<input type="checkbox" id="1"><label for="1">Web</label>
							<input type="checkbox" id="2"><label for="2">Army</label>
							<input type="checkbox" id="3"><label for="3">Police</label>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12">
						<select class="form-control form-control-sm">
						  <option>Bangladesh</option>
						  <option>India</option>
						  <option>Pakistan</option>
						  <option>Srilanka</option>
						  <option>Australia</option>
						</select>
					</div>
				</div>
				<div class="row">
					<div class="col-md-12 text-center mt-3">
						<button class="btn btn-outline-success">Submit</button>
					</div>
				</div>
				
				
				
			</form>
		</div>
		
	</body>
</html>