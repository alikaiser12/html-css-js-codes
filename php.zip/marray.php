<!DOCTYPE html>
<html>
	<head>
		<title>Array In Bootstrap Table</title>
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">

	</head>
	<body>
		
		<div class="container">
		
			<?php
				$sallery = array(
					array('Shakib', 'Web-Developer', '30', '35k', 'Dhaka'),
					array('Tamim', 'Cricketer', '32', '40k', 'Gazipur'),
					array('Murshed', 'Businessman', '40', '50k', 'Rangpur'),
					array('Abul', 'Farmer', '40', '20k', 'Khulna')
				);
				echo "<table class='table table-striped'>";
					echo "<tr>";
					echo "<th>Name</th>";
					echo "<th>Profession</th>";
					echo "<th>Age</th>";
					echo "<th>Sallery</th>";
					echo "<th>Hometown</th>";
					echo "</tr>";
					foreach($sallery as $saller){
						echo "<tr>";
						foreach($saller as $single){
							echo "<td>" . $single . "</td>";
						}
						echo "</tr>";
					}
				echo "</table>";
				
			?>
		
		</div>
		
	</body>
</html>