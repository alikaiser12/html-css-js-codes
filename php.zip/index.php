<?php

	//Indexed Array

	/*$country = array('Bangladesh', 'India', 'Pakistan', 'Nepal', 'Srilanka');
	
	$count = count($country);
	
	
	for($x = 0; $x < $count; $x++){
		echo "country names " . $country[$x] . "<br>";
	}
	
	$x = 0;
	while($x < $count){
		echo "country Name is " .$country[$x] . "<br>";
		$x++;
	}*/
	
	
	/*foreach($country as $countrysingle){
		echo $countrysingle . "<br>";
	}*/
	
	// Associative Array
	
	/* $names = array('Kohli' => '32', 'Rohit' => '35', 'Dhoni' => '40', 'Ruslan' => '60' );
	
	$key = array_keys($names);
	
	$count = count($key);
	$x = 0;
	while($x < $count){
		echo "Names " . $key[$x] . "<br>";
		$x++;
	} */
	
	
	// Multidimensional Array
	
	$sallery = array(
		array('Shakib', 'Web-Developer', '30', '35k', 'Dhaka'),
		array('Tamim', 'Cricketer', '32', '40k', 'Gazipur'),
		array('Murshed', 'Businessman', '40', '50k', 'Rangpur'),
		array('Abul', 'Farmer', '40', '20k', 'Khulna')
	);
	
	echo "<table>";
	echo "<tr>";
		echo "<th> Name </th>";
		echo "<th> Profession </th>";
		echo "<th> Age </th>";
		echo "<th> Sallery </th>";
		echo "<th> Hometown </th>";
	echo "</tr>";
	foreach($sallery as $sellar){
		echo "<tr>";
		foreach($sellar as $single){
			echo "<td>" . $single . "</td>";
		}
		echo "</tr>";
	}
	echo "</table>";
	
	/*echo "Name Is " . $sallery['0']['0'] . " Profession Is " . $sallery['0']['1'] . " Age Is " . $sallery['0']['2'] . " Sallery Is " . $sallery['0']['3'] . " Hometown Is " . $sallery['0']['4'] . "<br>";
	echo "Name Is " . $sallery['1']['0'] . " Profession Is " . $sallery['1']['1'] . " Age Is " . $sallery['1']['2'] . " Sallery Is " . $sallery['1']['3'] . " Hometown Is " . $sallery['1']['4'] . "<br>";
	echo "Name Is " . $sallery['2']['0'] . " Profession Is " . $sallery['2']['1'] . " Age Is " . $sallery['2']['2'] . " Sallery Is " . $sallery['2']['3'] . " Hometown Is " . $sallery['2']['4'] . "<br>";*/
	
	
	
	
	
	
	
	
	
	
	
	
	
	
?>