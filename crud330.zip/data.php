<?php
	require_once('header.php');
	require_once('database.php');
	
	$deleteid = isset($_GET['deleteid']) ? $_GET['deleteid'] : "";
	$query = "DELETE FROM information WHERE ID = $deleteid ";
	$sql = mysqli_query($con, $query);
	if($sql){
		$delete_success = "<div class='alert alert-success mb-2'>Data deleted successfully </div>";
	}
	
?>
	
	<div class="container mt-5">
		
		<div class="row text-center">
			<?php
				if(isset($delete_success)){
					echo $delete_success;
				}
			?>
			<a class="btn btn-secondary" href="index.php">Add Data</a>
		</div>
	
		<table class="table table-striped">
			<tr>
				<th>Id</th>
				<th>Name</th>
				<th>Email</th>
				<th>Subject</th>
				<th>Message</th>
				<th>Image</th>
				<th>Actions</th>
			</tr>
			<?php
				$datas = "SELECT * FROM information";
				$sql = mysqli_query($con, $datas);
				while($row = mysqli_fetch_assoc($sql) ) :
				
			?>
			<?php
			
				$image = $row['img'];
				if(empty($image)){
					$image = 'uploads/avatar.png';
				}else{
					$image = 'uploads/' .$row['img'];
				}
				
				
				
			?>
			<tr>
				<td><?php echo $row['id'] ; ?></td>
				<td><?php echo $row['name'] ; ?></td>
				<td><?php echo $row['email'] ; ?></td>
				<td><?php echo $row['subject'] ; ?></td>
				<td><?php echo $row['message'] ; ?></td>
				<td><img src="<?php echo $image ; ?>" alt="image" style="height: 100px; width: 100px;"></td>
				<td><a class="btn btn-warning" href="edit.php?edited=<?php echo $row['id'] ; ?>" style="margin-right: 5px;">Edit</a><a class="btn btn-danger" href="data.php?deleteid=<?php echo $row['id'] ; ?>">Delete</a></td>
			</tr>
			<?php endwhile; ?>
		</table>
	</div>

<?php
	require_once('footer.php');
?>