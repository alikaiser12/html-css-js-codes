<?php
	require_once('header.php');
	require_once('database.php');
	
	if(isset($_POST['submit'])){
		$name = $_POST['name'];
		$email = $_POST['email'];
		$subject = $_POST['subject'];
		$message = $_POST['message'];
		$imgdirectory = 'uploads';
		$imgupload = isset($_FILES['imgupload']) ? $_FILES['imgupload'] : '';
		$imgname = date('Y-m-d-h-i-sa') . $imgupload['name'];
		$imgtname = $imgupload['tmp_name'];
		
		$upload = move_uploaded_file($imgtname, "$imgdirectory/$imgname");
		
		
		$db_mail = "SELECT * FROM information WHERE email = '$email'";
		$db_query = mysqli_query($con, $db_mail);
		$count = mysqli_num_rows($db_query);
		
	
		
		
		
		
		$query = "INSERT INTO information (name, email, subject, message, img) VALUES ('$name', '$email', '$subject', '$message', '$imgname')";
		
		if($count > 0){
			$data_taken = "<div class='alert alert-warning'>Email already taken</div>";
		}else{
			$sql = mysqli_query($con, $query);
		}
		
		
		
		if(isset($sql)){
			$data_success = "<div class='alert alert-success'>Data Inserted Successfully</div>";
		}
		
	}
	

	
?>
		<div class="container mt-5">
			<div class="row text-center">
			
				<?php
					if(isset($data_success)){
						echo $data_success;
					}
					if(isset($data_error)){
						echo $data_error;
					}
					if(isset($data_taken)){
						echo $data_taken;
					}
					
				?>
				
				<a href="data.php" class="btn btn-secondary mt-2" >All Data </a>
			</div>
			<div class="row">
				<form method="POST" enctype="multipart/form-data">
					<div class="form-group mb-2">
						<label for="name">Full Name</label>
						<input type="text" name="name" id="name" class="form-control" required>
					</div>
					<div class="form-group mb-2">
						<label for="email">Email</label>
						<input type="email" name="email" id="email" class="form-control" required>
					</div>
					<div class="form-group mb-2">
						<label for="subject">Subject</label>
						<input type="text" name="subject" id="subject" class="form-control" required>
					</div>
					<div class="form-group">
						<label for="image">Image Upload</label>
						<input type="file" name="imgupload" id="image" class="form-control">
					</div>
					<div class="form-group mb-2">
						<label for="message">Message</label>
						<textarea id="message" name="message" class="form-control" required></textarea>
					</div>
					<div class="form-group text-center">
						<button class="btn btn-outline-secondary" name="submit">Submit</button>
					</div>
				</form>
			</div>
		</div>
<?php
	require_once('footer.php');
?>







