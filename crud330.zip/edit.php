<?php
	require_once('header.php');
	require_once('database.php');
	
	if(isset($_POST['update'])){
		$name = isset($_POST['name']) ? $_POST['name'] : '';
		$email = isset($_POST['email']) ? $_POST['email'] : '';
		$subject = isset($_POST['subject']) ? $_POST['subject'] : '';
		$message = isset($_POST['message']) ? $_POST['message'] : '';
		
		$id = isset($_GET['edited']) ? $_GET['edited'] : '' ;
		
		$query = "UPDATE information SET name = '$name', email = '$email', subject = '$subject', message = '$message' WHERE ID = $id ";
		$sql = mysqli_query($con, $query);
		
		if($sql){
			$data_success = "<div class='alert alert-success'>Data Updated Successfully</div>";
		}
		
	}
	
	
?>

	<div class="container mt-5">
		<div class="row">
			<?php
				if(isset($data_success)){
					echo $data_success;
				}
			?>
			<a href="data.php" class="btn btn-secondary mt-2" >All Data </a>
		</div>
		
		<div class="row">
			
			<?php
				$id = isset($_GET['edited']) ? $_GET['edited'] : "";
				$select = "SELECT * FROM information WHERE ID = $id ";
				$sql = mysqli_query($con, $select);
				$row = mysqli_fetch_assoc($sql);
			?>
			
			
			<form method="POST">
				<div class="form-group mb-2">
					<label for="name">Full Name</label>
					<input type="text" name="name" id="name" value="<?php echo $row['name'] ; ?>" class="form-control" required>
				</div>
				<div class="form-group mb-2">
					<label for="email">Email</label>
					<input type="email" name="email" value="<?php echo $row['email'] ; ?>" id="email" class="form-control" required>
				</div>
				<div class="form-group mb-2">
					<label for="subject">Subject</label>
					<input type="text" name="subject" value="<?php echo $row['subject'] ; ?>" id="subject" class="form-control" required>
				</div>
				<div class="form-group mb-2">
					<label for="message">Message</label>
					<textarea id="message" name="message" class="form-control" required><?php echo $row['message'] ; ?></textarea>
				</div>
				<div class="form-group text-center">
					<button class="btn btn-outline-secondary" name="update">update</button>
				</div>
			</form>
		</div>
		
	</div>
	
<?php
	require_once('footer.php');
?>