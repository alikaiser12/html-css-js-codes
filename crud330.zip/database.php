<?php
	$hostname = "localhost";
	$username = "root";
	$password = "";
	$db = "datas";

	$con = mysqli_connect("$hostname", "$username", "$password", "$db");
?>