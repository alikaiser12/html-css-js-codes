$(document).ready(function(){
	$(".hide").click (function(){
		$(".img3").slideUp(300);
	});
});